# Gielinor-Resources

This resource pack is dedicated to bringing a unique Runescape experience into Minecraft. Initial projects towards the Gielinor project were started years ago in early February of 2018. This resource has been actively being produced for a little over a year. 

![Creative Commons License](https://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png)<br>
This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-nc-sa/3.0/). [Additional terms may apply](meta/COPYRIGHTS.md).
*RuneScape* and *RuneScape Old School* are the trademarks of [Jagex Limited](http://jagex.com/) and are used with the permission of Jagex.