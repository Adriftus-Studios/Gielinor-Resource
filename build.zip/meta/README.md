# Gielinor-Resources

![Creative Commons License](https://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png)<br>
This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-nc-sa/3.0/). [Additional terms may apply](meta/COPYRIGHTS.md).
*RuneScape* and *RuneScape Old School* are the trademarks of [Jagex Limited](http://jagex.com/) and are used with the permission of Jagex.